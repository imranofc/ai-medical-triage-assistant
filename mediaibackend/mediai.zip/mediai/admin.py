from django.contrib import admin
from .models import *

admin.site.register(Consultation)
admin.site.register(PatientDetail)